package com.example.ecs_c5g7;

public class Constant {
}
